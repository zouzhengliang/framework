/**
 * Utility classes for using and implementing SSL within XNIO providers.
 */
package org.xnio.ssl;
