/**
 * The core XNIO channel API.
 */
package org.xnio.channels;
